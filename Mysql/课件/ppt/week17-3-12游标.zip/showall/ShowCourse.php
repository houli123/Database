﻿<?php
include("db_conn.php");
include("db_func.php");

$ShowCourse_sql = "SELECT * FROM Course ORDER BY CouNo"; 
$ShowCourseResult = db_query($ShowCourse_sql); 
?>
<html>
<head>
<meta http-equiv="Content-Type"content="text/html; charset=utf8" />
<title>课程信息显示</title>
</head>
<body>
<center>点击课程编码链接可以查看课程细节</center>
<table width="610" border="0" align="center" cellpadding="0" cellspacing="1">
    <tr bgcolor="#0066CC"> 
      <td width="80" align="center"><font color="#FFFFFF">课程编码</font></td>
      <td width="220" align="center"><font color="#FFFFFF">课程名称</font></td>
      <td width="80"><font color="#FFFFFF" align="center">课程类别</font></td>
      <td width="50"><font color="#FFFFFF" align="center">学分</font></td>
      <td width="80"><font color="#FFFFFF" align="center">任课教师</font></td>
      <td width="100"><font color="#FFFFFF" align="center">上课时间</font></td>
    </tr>


<?php
$number = db_num_rows($ShowCourseResult); 
if ($number>0) { 
   
   for ($i = 0; $i < $number; $i++) {
       $row = db_fetch_array($ShowCourseResult);
       if ($i%2 == 0) 
           echo "<tr bgcolor='#DDDDDD'>";
       else
           echo "<tr>";
       echo "<td width='80' align='center'><a href='CourseDetail.php?CouNo=".$row['CouNo']."'>".$row['CouNo']."</a></td>";
       echo "<td width='220'>".$row['CouName']."</td>";
       echo "<td width='80'>".$row['Kind']."</td>";
       echo "<td width='50'>".$row['Credit']."</td>";
       echo "<td width='80'>".$row['Teacher']."</td>";
       echo "<td width='100'>".$row['SchoolTime']."</td>";
       echo "</tr>";
    }
} 

?>
</table>

</center>
</body>
</html>
